import sys
import random
import time
import re

class DealerChips:
    def __init__(self): #open the file
        self.f=open("dealer_chips.txt", "a") #or "a"
    def writechips(self, mytext): #write the text you want
        self.f.write("%s\n" % mytext)
    def closechips(self): #close the file when necessary 
        self.f.close()
        
        
class PlayerChips:
    def __init__(self): #open the file
        self.f=open("player_chips.txt", "a") #or "a"
    def writechips(self, mytext): #write the text you want
        self.f.write("%s\n" % mytext)
    def closechips(self): #close the file when necessary 
        self.f.close()
        
class Main:
    max_width = 5
    max_height = 5
    n=0
    choice=0
    player_turn=False
    dealer_turn=True
    d_tot_pts = 0
    p_tot_pts = 0
    dealer_tot_pts = 0
    player_tot_pts = 0
    hand1 = []
    hand2 = []
    dealer_pts = []
    player_pts = []
    dealer = []
    player = []
    dealer1=0
    player1=0
    
    keyval = {'T':10,'J':10,'Q':10,'K':10,'A':11}
    
    p=PlayerChips()
    d=DealerChips()      
            
    def __init__(self):
        self._queue = []
        self.index = 0
        self.chips_on_bet = 10
        self.dealer_chips = []
        self.player_chips = []
        self.x_cards_list = []
        #self.display_menu()
    def getline(self,user):
        if(user == 'Dealer'):
            self.f=open("dealer_chips.txt", "r")
        elif(user == 'Player'):
            self.f=open("player_chips.txt", "r")    
        self.lines=self.f.readlines()
        self.lastline=self.lines[(len(self.lines)-1)]
        print(self.lastline)
        
        try:
            oldbal = re.match(r'\d+',self.lastline)
            oldbal.group(0)
        except AttributeError:
            oldbal = re.match(r'\d\d',self.lastline)
            oldbal.group(0)
        
        return(oldbal.group(0))
        print(oldbal.group(0))

    #Shuffling Cards
    def shuffle_cards(self):
        self.nums = [ suit + rank for rank in "A23456789TJQK" for suit in 'CDHS']
        #print(self.nums)
        self.cards_list = self.nums
        random.shuffle(self.cards_list)
        return self.cards_list
    
    #Picking Cards at first hand    
    def pick_cards(self,n,cards_list):
        print()
        return[self.cards_list.pop() for k in range(n)]
    
    #Check for push condition
    def check_push(self,p_tot_pts,d_tot_pts):
        if(p_tot_pts == d_tot_pts):
            print("Player and Dealer are having equal points.It is a Push")
            print("Restarting the game:-Dealer")
            sys.exit(0)
            self.display_menu
    
    #Check for winner    
    def check_winner(self,p_tot_pts,d_tot_pts):
        if(21 % p_tot_pts == 0) or (21 % d_tot_pts == 0) :
            if(p_tot_pts == 21):
                print("Player won BlackJack")
                d=DealerChips()
                p=PlayerChips()
        
                user = 'Player'
                self.player_chips.append(int(self.getline(user))) 
                self.player_chips.append(int(self.chips_on_bet*1.5))
                print("Player is having %d " % sum(self.player_chips))
                p.writechips("%s chips are with the Player" % str(sum(self.player_chips)))
                del self.player_chips[0]
                p.closechips()
                
                user = 'Dealer'
                self.dealer_chips.append(int(self.getline(user)))
                self.dealer_chips.append(int(-self.chips_on_bet*1.5))
                print("Dealer is having %d " % sum(self.dealer_chips))
                d.writechips("%s chips are with the Dealer" % str(sum(self.dealer_chips)))
                del self.dealer_chips[0]
                d.closechips()
                
                print("Restart the game:-Dealer")
                sys.exit(0)
                self.display_menu
            elif(d_tot_pts == 21):
                print("Dealer won BlackJack")
                d=DealerChips()
                p=PlayerChips()
        
                user = 'Dealer'
                self.dealer_chips.append(int(self.getline(user)))
                self.dealer_chips.append(int(self.chips_on_bet*1.5))
                print("Dealer is having %d " % sum(self.dealer_chips))
                d.writechips("%s chips are with the Dealer" % str(sum(self.dealer_chips)))
                del self.dealer_chips[0]
                d.closechips()
               
                user = 'Player'
                self.player_chips.append(int(self.getline(user))) 
                self.player_chips.append(int(-self.chips_on_bet*1.5))
                print("Player is having %d " % sum(self.player_chips))
                p.writechips("%s chips are with the Player" % str(sum(self.player_chips)))
                del self.player_chips[0]
                p.closechips()
                
                print("Restart the game:-Dealer")
                sys.exit(0)
                self.display_menu
        elif(d_tot_pts > 21): #check bust for dealer
            print("Dealer is bust")
            d=DealerChips()
            p=PlayerChips()
        
            user = 'Dealer'
            self.dealer_chips.append(int(self.getline(user)))
            self.dealer_chips.append(int(-self.chips_on_bet))
            print("Dealer is having %d " % sum(self.dealer_chips))
            d.writechips("%s chips are with the Dealer" % str(sum(self.dealer_chips)))
            del self.dealer_chips[0]
            d.closechips()
                
            user = 'Player'
            self.player_chips.append(int(self.getline(user))) 
            self.player_chips.append(int(self.chips_on_bet))
            print("Player is having %d " % sum(self.player_chips))
            p.writechips("%s chips are with the Player" % str(sum(self.player_chips)))
            del self.player_chips[0]
            p.closechips()
                
            print("Restart the game:-Dealer")
            sys.exit(0)
            self.display_menu
                
        elif(p_tot_pts > 21): #check bust for Player
            print("Player is bust")
            
            d=DealerChips()
            p=PlayerChips()
        
            user = 'Player'
            self.player_chips.append(int(self.getline(user))) 
            self.player_chips.append(int(-self.chips_on_bet))
            print("Player is having %d " % sum(self.player_chips))
            p.writechips("%s chips are with the Player" % str(sum(self.player_chips)))
            del self.player_chips[0]
            p.closechips()
            
            user = 'Dealer'
            self.dealer_chips.append(int(self.getline(user)))
            self.dealer_chips.append(int(self.chips_on_bet))
            print("Dealer is having %d " % sum(self.dealer_chips))
            d.writechips("%s chips are with the Dealer" % str(sum(self.dealer_chips)))
            del self.dealer_chips[0]
            d.closechips()
                
            print("Restart the game:-Dealer")
            sys.exit(0)
            self.display_menu
            
    #Displaying menu       
    def display_menu(self):
        menu_list = ['New Game','Check/Add Chips','Exit']
        print()
        print("Type the number of your choice")
        print()
 
        for i in range(1,len(menu_list) + 1):
            print(str(i) + ') ' + menu_list[i-1])
        
        print()    
        choice = input('Please enter your choice =>   ')
        self.menu_choice(choice)
    
    #Displaying menu choices
    def menu_choice(self,choice):
        try:
            choice = int(choice) #if choice entered in NOT integer,it hits value error
        except ValueError:
            choice = 0        

        if(choice == 1):
            n=2
            print()
            time.sleep(3)
            self.play_game(n)
        elif(choice == 2):
            p=PlayerChips()
            user='Player'
            print(self.getline(user))
            add_chips = input('Enter yes or no if you want to add more chips=>  ')
            if (add_chips == 'yes'):
                more_chips = float(input('Enter number(integer) of chips to be added=>  '))
                print()
                self.player_chips.append(more_chips)
                self.player_chips.append(int(self.getline(user)))
                tot_player = sum(self.player_chips)
                #print(tot_player)
                p.writechips("%d chips are with the Player" % tot_player)
                print("Player's on hand balance of chips are=> %d " % tot_player )
                print()
                return
                
            else:
                print("You are exiting the game")
                sys.exit(0)
        elif(choice == 3):
            print()
            print('You are exiting the game')
            sys.exit(0) #
            self.display_menu
        else:
            print()
            print('That was n\'t a valid option. Try again ')
            self.display_menu()

    #Calculate total points
    def total_points(self,player_tot_pts,dealer_tot_pts,player1,dealer1):
        self.player_pts.append(player_tot_pts)
        self.dealer_pts.append(dealer_tot_pts)
        self.player_pts.append(player1)
        self.dealer_pts.append(dealer1)
        self.totd = sum(self.dealer_pts)
        self.totp = sum(self.player_pts)
        print("Total Points of Player:   %s " % self.totp)
        print("Total Points of Dealer:   %s " % self.totd)
    
    #Drawing Cards By Dealer    
    def draw_card(self,turn):
        if(turn == True):
            n=1
            self.hand2 = self.pick_cards(n,self.x_cards_list)
            self.dealer.append(self.hand2[0])
            print("Dealer gets = %s  " % self.hand2[0])
            print("Cards with the Dealer are = %s " % self.dealer)
            print("Cards remaining = %s cards " % len(self.cards_list) )
                
            #dealer info
            d_hand1_str = self.hand2[0]
        
            if(d_hand1_str[1] == 'A'):
                self.dealer1 = self.keyval.get('A')
            elif(d_hand1_str[1] == 'T'):
                self.dealer1 = self.keyval.get('T')
            elif(d_hand1_str[1] == 'J'):
                self.dealer1 = self.keyval.get('J')
            elif(d_hand1_str[1] == 'Q'):
                self.dealer1 = self.keyval.get('Q')
            elif(d_hand1_str[1] == 'K'):
                self.dealer1 = self.keyval.get('K')
            else:
                dealer_1 = d_hand1_str[1]
                self.dealer1 = int(dealer_1)
    
    #Play the game
    def play_game(self,n):
        user = 'Player'
        if(user == 'Player'):
            player_bal = int(self.getline(user))
            if (player_bal <= 0):
                print("Please add more chips by selecting 2 from the menu:::")
                sys.exit(0)   
        if( n == 2):
            print("Dealer is shuffling cards")
            d=DealerChips()
            p=PlayerChips()
            #shuffle the new deck       
            self.cards_list = self.shuffle_cards()
            print(self.cards_list)
            print("Shuffled cards count is = %s cards " % len(self.cards_list) )
            
            # Take a cut
            print("Please cut the cards by entering:- ok  ")    
            user_input = input('Please cut the cards =>   ')
            
            if(user_input == 'ok'):
                no_of_cards = random.randint(1,30)
            
            
            print("Please enter the number of chips(1-100) on bet")
            self.chips_on_bet = int(input('Please enter the number between 1 and 100 =>   '))
             
            #delete sub list   
            del self.cards_list[0:(no_of_cards - 1) + 1]
            
            #display balance cards
            print(self.cards_list)
            
            #draw cards        
            self.hand1 = self.pick_cards(n,self.cards_list)
            self.hand2 = self.pick_cards(n,self.cards_list)
        
            print("Player gets first card = %s  " % self.hand1[0])
            self.player.append(self.hand1[0])
            
            print("Dealer gets first card = %s  " % self.hand1[1])
            self.dealer.append(self.hand1[1])
            
            print("Player gets Second card = %s  " % self.hand2[0])
            self.player.append(self.hand2[0])
            
            print("Dealer gets Second card = %s  " % self.hand2[1])
            self.dealer.append(self.hand2[1])
            
            print("Cards with the Player are = %s " % self.player)
            print("Cards with the Dealer are = %s " % self.dealer)
            
            print()
            print("Cards remaining are = %s cards " % len(self.cards_list) )
            print()
            self.x_cards_list  =self.cards_list
            self.x_count = len(self.cards_list)
        
            #player info
            p_hand1_str =self.hand1[0]
            p_hand2_str = self.hand2[0]
        
            if(p_hand1_str[1] == 'A'):
                player1 = self.keyval.get('A')
            elif(p_hand1_str[1] == 'T'):
                player1 = self.keyval.get('T')
            elif(p_hand1_str[1] == 'J'):
                player1 = self.keyval.get('J')
            elif(p_hand1_str[1] == 'Q'):
                player1 = self.keyval.get('Q')
            elif(p_hand1_str[1] == 'K'):
                player1 = self.keyval.get('K')
            else:
                player_1 = p_hand1_str[1]
                player1 = int(player_1)
        
        
            if(p_hand2_str[1] == 'A'):
                player2 = self.keyval.get('A')
            elif(p_hand2_str[1] == 'T'):
                player2 = self.keyval.get('T')
            elif(p_hand2_str[1] == 'J'):
                player2 = self.keyval.get('J')
            elif(p_hand2_str[1] == 'Q'):
                player2 = self.keyval.get('Q')
            elif(p_hand2_str[1] == 'K'):
                player2 = self.keyval.get('K')
            else:
                player_2 = p_hand2_str[1]
                player2 = int(player_2)
        
            player_tot_pts = player1 + player2
            print("Player got %d points " % player_tot_pts)
            
            #dealer info
            d_hand1_str = self.hand1[1]
            d_hand2_str = self.hand2[1]
        
            if(d_hand1_str[1] == 'A'):
                dealer1 = self.keyval.get('A')
            elif(d_hand1_str[1] == 'T'):
                dealer1 = self.keyval.get('T')
            elif(d_hand1_str[1] == 'J'):
                dealer1 = self.keyval.get('J')
            elif(d_hand1_str[1] == 'Q'):
                dealer1 = self.keyval.get('Q')
            elif(d_hand1_str[1] == 'K'):
                dealer1 = self.keyval.get('K')
            else:
                dealer_1 = d_hand1_str[1]
                dealer1 = int(dealer_1)
        
            if(d_hand2_str[1] == 'A'):
                dealer2 = self.keyval.get('A')
            elif(d_hand2_str[1] == 'T'):
                dealer2 = self.keyval.get('T')
            elif(d_hand2_str[1] == 'J'):
                dealer2 = self.keyval.get('J')
            elif(d_hand2_str[1] == 'Q'):
                dealer2 = self.keyval.get('Q')
            elif(d_hand2_str[1] == 'K'):
                dealer2 = self.keyval.get('K')
            else:
                dealer_2 = d_hand2_str[1]
                dealer2 = int(dealer_2)
               
            dealer_tot_pts= dealer1 + dealer2
            print("Dealer got %d points" % dealer_tot_pts)
            
            self.total_points(player_tot_pts,dealer_tot_pts,0,0)
            x_tot_pts = player_tot_pts        
            #self.dealer_pts.append(dealer_tot_pts)
            #self.player_pts.append(player_tot_pts)
            #print(self.player_pts)
            #print(self.dealer_pts)
            
            # NEW LOGIC VBRAJU
            if(self.totp >= 16):
                print("Dealer turn to flip second card and draw cards,if needed")
                self.dealer_turn = True
                #force dealer to draw cards if points < 17
                for i in range(1,5):
                    if(self.totd < 17):
                        print("Oops!! Dealer points are < 17! Dealer is picking the cards, please wait")
                        time.sleep(3)
                        self.draw_card(self.dealer_turn)    
                        print("the dealer in iteration:  %s" % self.dealer1)
                        self.total_points(0,0,0,self.dealer1)
                        self.x_cards_list  =self.cards_list
                    elif(self.totd >= 17):
                        print("Checking for push and winner: ")
                        time.sleep(5)
                        #check for push
                        self.check_push(self.totd,self.totp)        
                
                        #check for winner
                        self.check_winner(self.totp, self.totd)
                
                #check for push
                self.check_push(self.totd,self.totp)        
                
                #check for winner
                self.check_winner(self.totp, self.totd)
        
        # end of new draw card logic--if points <17
        
            elif(self.totp <= 15):
                n=1
                print()
                for i in range(1,6):
                    print('Player to hit the cards upon discretion ')
                    player_input = input("Please enter yes to take the card:- ")
                    if player_input == 'yes':
                        print("Player is in standing::::")
                        self.player_turn=True
                        self.TapTable(n,i)
                        time.sleep(3)
                    elif player_input == 'no':
                        print('Dealer should start drawing cards')
                        n=1
                        print()
                        print("Dealer turn after standing ::::")
                        print()
                        self.player_turn = False
                        for i in range(1,6):
                            self.dealer_turn=True
                            #self.TapTable(n,i)
                            time.sleep(6)
                            if (self.totd <= 17):
                                print("Oops!! Dealer points are <= 17! Dealer is picking the cards, please wait")
                                time.sleep(6)
                                n=1
                                self.hand2 = self.pick_cards(n,self.x_cards_list)
                                self.dealer.append(self.hand2[0])
                                print("Dealer got %s card " % self.hand2[0])
                                print("Cards with the Dealer are = %s " % self.dealer)
                                print("Cards remaining are = %s cards " % len(self.cards_list) )
                
                                #dealer info
                                d_hand1_str = self.hand2[0]
        
                                if(d_hand1_str[1] == 'A'):
                                    dealer1 = self.keyval.get('A')
                                elif(d_hand1_str[1] == 'T'):
                                    dealer1 = self.keyval.get('T')
                                elif(d_hand1_str[1] == 'J'):
                                    dealer1 = self.keyval.get('J')
                                elif(d_hand1_str[1] == 'Q'):
                                    dealer1 = self.keyval.get('Q')
                                elif(d_hand1_str[1] == 'K'):
                                    dealer1 = self.keyval.get('K')
                                else:
                                    dealer_1 = d_hand1_str[1]
                                    dealer1 = int(dealer_1)
        
                            print("Dealer after player's standing:  %s"  % dealer1 + "iteration: %d"  %  i)
                            self.total_points(0,0,0,dealer1)
                            self.x_cards_list  =self.cards_list
                            
                            #check for push
                            self.check_push(self.totd,self.totp)        
                
                            #check for winner
                            self.check_winner(self.totp, self.totd)

                            #check for bust
                            if(self.totd > 21):
                                self.dealer_turn=False
                                print('Dealer lost the bet')
                
                                d=DealerChips()
                                p=PlayerChips()
                                        
                                user = 'Dealer'
                                self.dealer_chips.append(int(self.getline(user)))
                                self.dealer_chips.append(int(-self.chips_on_bet))
                                print("Dealer is having %d " % sum(self.dealer_chips))
                                d.writechips("%s chips are with the Dealer" % str(sum(self.dealer_chips)))
                                del self.dealer_chips[0]
                                d.closechips()

                                user = 'Player'
                                self.player_chips.append(int(self.getline(user))) 
                                self.player_chips.append(int(self.chips_on_bet))
                                print("Player is having %d " % sum(self.player_chips))
                                p.writechips("%s chips are with the Player" % str(sum(self.player_chips)))
                                del self.player_chips[0]
                                p.closechips()
                
                                print('Restart the game:-Dealer')
                                sys.exit(0)
                                self.display_menu
                
                
            #check for push
            self.check_push(self.totd,self.totp)        
                
            #check for winner
            self.check_winner(self.totp, self.totd)

    #iteration logic starts here
    def TapTable(self,n,i):
        if( self.player_turn == True):
            if (n == 1):
                #draw cards        
                self.hand1 = self.pick_cards(n,self.x_cards_list)
                #if(self.hand1):
                self.player.append(self.hand1[0])
                print("Player got %s card" % self.hand1[0])
                print("Cards with the Player are = %s " % self.player)
                print("Cards remaining are = %s " % len(self.cards_list) )
                self.x_cards_list=self.cards_list
        
                #player info
                p_hand1_str =self.hand1[0]
                #print(p_hand1_str)
                #print(p_hand1_str[1])
                
                if(p_hand1_str[1] == 'A'):
                    player1 = self.keyval.get('A')
                elif(p_hand1_str[1] == 'T'):
                    player1 = self.keyval.get('T')
                elif(p_hand1_str[1] == 'J'):
                    player1 = self.keyval.get('J')
                elif(p_hand1_str[1] == 'Q'):
                    player1 = self.keyval.get('Q')
                elif(p_hand1_str[1] == 'K'):
                    player1 = self.keyval.get('K')
                else:
                    player_1 = p_hand1_str[1]
                    player1 = int(player_1)
        
                print("the player is in standing:  %s"  % player1 + " standing: %d"  %  i)
                self.total_points(0,0,player1,0)
                if(self.totp > 21):
                    self.player_turn=False
                    print('Player lost the bet')
        
                    d=DealerChips()
                    p=PlayerChips()
                    
                    user = 'Dealer'
                    self.dealer_chips.append(int(self.getline(user)))
                    self.dealer_chips.append(int(self.chips_on_bet))
                    print("Dealer is having %d " % sum(self.dealer_chips))
                    d.writechips("%s chips are with the Dealer" % str(sum(self.dealer_chips)))
                    del self.dealer_chips[0]
                    d.closechips()

                    user = 'Player'
                    self.player_chips.append(int(self.getline(user))) 
                    self.player_chips.append(int(-self.chips_on_bet))
                    print("Player is having %d " % sum(self.player_chips))
                    p.writechips("%s chips are with the Player" % str(sum(self.player_chips)))
                    del self.player_chips[0]
                    p.closechips()
                
                    print('Restart the game:-Dealer')
                    sys.exit(0)
                    self.display_menu
                elif(self.totp == 21):
                    #check for push
                    self.check_push(self.totd,self.totp)        
                
                    #check for winner
                    self.check_winner(self.totp, self.totd)
                elif(self.totp <= 16):
                    time.sleep(5)
                elif(self.totd <= 17):
                    print("Oops!! Dealer points are <= 17! Dealer is picking the cards, please wait")
                    time.sleep(6)
                    n=1
                    self.hand2 = self.pick_cards(n,self.x_cards_list)
                    self.dealer.append(self.hand2[0])
                    print("Dealer got %s card " % self.hand2[0])
                    print("Cards with the Dealer are = %s " % self.dealer)
                    print("Cards remaining are = %s cards " % len(self.cards_list) )
                
                    #dealer info
                    d_hand1_str = self.hand2[0]
        
                    if(d_hand1_str[1] == 'A'):
                        dealer1 = self.keyval.get('A')
                    elif(d_hand1_str[1] == 'T'):
                        dealer1 = self.keyval.get('T')
                    elif(d_hand1_str[1] == 'J'):
                        dealer1 = self.keyval.get('J')
                    elif(d_hand1_str[1] == 'Q'):
                        dealer1 = self.keyval.get('Q')
                    elif(d_hand1_str[1] == 'K'):
                        dealer1 = self.keyval.get('K')
                    else:
                        dealer_1 = d_hand1_str[1]
                        dealer1 = int(dealer_1)
        
                        print("Dealer after player's standing:  %s"  % dealer1 + "iteration: %d"  %  i)
                        self.total_points(0,0,0,dealer1)
                        self.x_cards_list  =self.cards_list
                        #check for bust
                        if(self.totd > 21):
                            self.dealer_turn=False
                            print('Dealer lost the bet')
                
                            d=DealerChips()
                            p=PlayerChips()
                                        
                            user = 'Dealer'
                            self.dealer_chips.append(int(self.getline(user)))
                            self.dealer_chips.append(int(-self.chips_on_bet))
                            print("Dealer is having %d " % sum(self.dealer_chips))
                            d.writechips("%s chips are with the Dealer" % str(sum(self.dealer_chips)))
                            del self.dealer_chips[0]
                            d.closechips()

                            user = 'Player'
                            self.player_chips.append(int(self.getline(user))) 
                            self.player_chips.append(int(self.chips_on_bet))
                            print("Player is having %d " % sum(self.player_chips))
                            p.writechips("%s chips are with the Player" % str(sum(self.player_chips)))
                            del self.player_chips[0]
                            p.closechips()
                
                            print('Restart the game:-Dealer')
                            sys.exit(0)
                            self.display_menu
                            #check for push
                            self.check_push(self.totd,self.totp)        
                
                            #check for winner
                            self.check_winner(self.totp, self.totd)
        
                        else:    
                            pass
                            #self.player_turn=True
                
        #check for push
        self.check_push(self.totd,self.totp)        
                
        #check for winner
        self.check_winner(self.totp, self.totd)
                
BlackJack = Main()
BlackJack.display_menu()

